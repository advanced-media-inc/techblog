﻿using System.ComponentModel;
using System.Diagnostics;

namespace RecorderSampleApp.ViewModel
{
    public abstract class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;


    }
}
