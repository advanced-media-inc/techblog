﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;

namespace RecorderSampleApp
{
    /*
     * References
     * https://briangrinstead.com/blog/multipart-form-post-in-c/
     * http://surferonwww.info/BlogEngine/post/2019/08/11/file-upload-by-using-httpclient.aspx
     * https://iwasiman.hatenablog.com/entry/20210622-CSharp-HttpClient
     * https://husk.hatenablog.com/entry/2018/07/24/231738
     */

    public class AmiHTTP
    {
        // -> const
        private const string urlPath = "https://acp-api-async.amivoice.com/v1/recognitions";
        private static readonly Encoding encoding = Encoding.UTF8;

        // 
        private static HttpClient _client = new(); // 枯渇対策

        // 
        public class AmiHTTPResult
        {
            public string success = null;
            public string error = null;
        }

        // -> POST (音声認識のリクエスト)
        public static async Task RequestSpeechRecog(string filePath, string appKey, string dValue, Action<AmiHTTPResult> action)
        {

            // -> make content
            using MultipartFormDataContent content = new();

            // -> u
            content.Add(new StringContent(appKey, encoding), "\"u\"");
            // -> d
            content.Add(new StringContent(dValue, encoding), "\"d\"");
            // -> a
            //content.Add(new StringContent(wavStr, Encoding.Unicode, "application/octet-stream"), "\"a\""); // -> この送り方は間違い
            using FileStream fs = new(filePath, FileMode.Open, FileAccess.Read);
            StreamContent streamContent = new(fs);
            streamContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
            {
                Name = "\"a\"",
            };
            streamContent.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            content.Add(streamContent);

            HttpRequestMessage request = new(HttpMethod.Post, urlPath);
            request.Content = content;

            //Debug.WriteLine(request.Content.ReadAsStringAsync().Result);

            await DoRequest(request, action);
        }

        // -> GET (ジョブの取得)
        public static async Task GetJobState(string session_id, string appKey, Action<AmiHTTPResult> action)
        {
            string path_ = urlPath + "/" + session_id;

            HttpRequestMessage request = new(HttpMethod.Get, path_);
            request.Headers.Add("Authorization", "Bearer " + appKey);

            await DoRequest(request, action);
        }

        // -> Request
        private static async Task DoRequest(HttpRequestMessage request, Action<AmiHTTPResult> action)
        {
            HttpStatusCode statusCoode = HttpStatusCode.NotFound;
            string bodyStr;
            AmiHTTPResult result = new();

            try
            {
                HttpResponseMessage response = await _client.SendAsync(request);
                bodyStr = await response.Content.ReadAsStringAsync();
                statusCoode = response.StatusCode;
            }
            catch (HttpRequestException e)
            {
                Debug.WriteLine("e: " + e.Message);
                result.error = "ERROR: " + e.Message;
                action(result);
                return;
            }

            if (!statusCoode.Equals(HttpStatusCode.OK))
            {
                result.error = "ERROR: StatusCode = " + statusCoode;
                action(result);
                return;
            }

            if (string.IsNullOrEmpty(bodyStr))
            {
                result.error = "ERROR: Response body is empty";
                action(result);
                return;
            }

            result.success = bodyStr;
            action(result);
        }

        //
        #region - Others
        // -> Others 

        public static void postTest(string appKey)
        {
            string boundary = string.Format("-----{0:N}", Guid.NewGuid());
            string contentType = "multipart/form-data; boundary=" + boundary;

            // -> body
            Stream formDataStream = new MemoryStream();

            // -> appkey
            string data1 = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"{1}\"\r\n\r\n{2}",
                boundary,
                "u",
                appKey);
            formDataStream.Write(encoding.GetBytes(data1), 0, encoding.GetByteCount(data1));

            // -> grammer
            string data2 = string.Format("\r\n--{0}\r\nContent-Disposition: form-data; name=\"{1}\"\r\n\r\n{2}",
                boundary,
                "d",
                "grammarFileNames=-a-general speakerDiarization=True");
            formDataStream.Write(encoding.GetBytes(data2), 0, encoding.GetByteCount(data2));

            // -> audio file
            string data3 = string.Format("\r\n--{0}\r\nContent-Disposition: form-data; name=\"{1}\"\r\nContent-Type: application/octet-stream\r\n\r\n",
                boundary,
                "a");
            formDataStream.Write(encoding.GetBytes(data3), 0, encoding.GetByteCount(data3));

            byte[] wav = File.ReadAllBytes("./audio/test.wav");

            formDataStream.Write(wav, 0, wav.Length);

            // -> Footer
            string footer = "\r\n--" + boundary + "--\r\n";
            formDataStream.Write(encoding.GetBytes(footer), 0, encoding.GetByteCount(footer));

            // -> Dump the Stream into a byte[]
            formDataStream.Position = 0;
            byte[] formData = new byte[formDataStream.Length];
            formDataStream.Read(formData, 0, formData.Length);
            formDataStream.Close();

            string log = encoding.GetString(formData);
            Debug.WriteLine("content log: " + log);

            // -> Request
            HttpWebRequest request = WebRequest.Create(urlPath) as HttpWebRequest;
            if (request == null)
            {
                throw new NullReferenceException("request is not a http request");
            }

            request.Method = "POST";
            request.ContentType = contentType;
            request.CookieContainer = new CookieContainer();
            request.ContentLength = formData.Length;

            using Stream requestStream = request.GetRequestStream();
            requestStream.Write(formData, 0, formData.Length);
            requestStream.Close();
            //ServicePointManager.Expect100Continue = false;

            HttpWebResponse response = request.GetResponse() as HttpWebResponse;

            // Process response
            StreamReader responseReader = new StreamReader(response.GetResponseStream());
            string fullResponse = responseReader.ReadToEnd();
            response.Close();
            Debug.Write(fullResponse);
        }

        public static void getTest(string session_id, string appKey)
        {
            string path_ = urlPath + "/" + session_id;//"017e8fdaf3a80a306b8f9c98";
            // -> Request
            HttpWebRequest request = WebRequest.Create(path_) as HttpWebRequest;
            if (request == null)
            {
                throw new NullReferenceException("request is not a http request");
            }
            request.Headers.Add("Authorization", "Bearer " + appKey);
            request.Method = "GET";

            HttpWebResponse response = request.GetResponse() as HttpWebResponse;

            // Process response
            StreamReader responseReader = new StreamReader(response.GetResponseStream());
            string fullResponse = responseReader.ReadToEnd();
            response.Close();
            Debug.Write(fullResponse);
        }
        #endregion
    }
}