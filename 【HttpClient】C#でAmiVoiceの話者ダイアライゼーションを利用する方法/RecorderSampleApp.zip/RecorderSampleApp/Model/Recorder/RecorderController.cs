﻿using NAudio.CoreAudioApi;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;

namespace RecorderSampleApp
{ 
    class RecorderController
    {
        private static string _save_path = "c:/programdata/RecorderSampleApp/Audios/";
        private Recorder _recorder;

        public RecorderController()
        {
            // 音声ファイル保存先のパスがなければ作る
            if (!Directory.Exists(_save_path))
            {
                DirectoryInfo info = Directory.CreateDirectory(_save_path);
                Debug.WriteLine("info: " + info);
            }

            _recorder = new();
        }

        #region - Public
        /*
        public void SetListener(UnisysListener listener)
        {
            listener_ = listener;
        }*/
        public bool StartRecord()
        {
            if (_recorder == null) { return false; }

            if (GetAvailableMicDeviceCount() < 1) { return false; }

            if (!Directory.Exists(_save_path))
            {
                DirectoryInfo info = Directory.CreateDirectory(_save_path);
            }

            string path = _save_path + "/" + GetFileName();

            if (!_recorder.Setup(path)) { return false; }

            _recorder.Start();

            return true;
        }

        public bool StopRecord()
        {
            if (_recorder == null) { return false; }

            _recorder.Stop();
            return true;
        }

        public bool IsRecording()
        {
            if (_recorder == null) { return false; }

            return _recorder.IsRecording;
        }


        public string[] GetAvailableMicDevices()
        {
            //Instantiate an Enumerator to find audio devices
            MMDeviceEnumerator MMDE = new();
            //Get all the devices, no matter what condition or status
            MMDeviceCollection DevCol = MMDE.EnumerateAudioEndPoints(DataFlow.Capture, DeviceState.Active);

            string[] devices = new string[DevCol.Count];

            for (int i = 0; i < DevCol.Count; i++)
            {
                devices[i] = DevCol[i].DeviceFriendlyName;
            }
                 
            return devices;
        }

        public int GetAvailableMicDeviceCount()
        {
            return GetAvailableMicDevices().Length;
        }

        public string GetFirstAvailableMicName()
        {
            string[] devices = GetAvailableMicDevices();
            if (devices == null) { return ""; }
            if (devices.Length < 1) { return ""; }

            return devices[0];
        }

        #endregion


        #region - Private

        private string GetFileName()
        {
            DateTime n = DateTime.Now;
            string tmp = string.Format("{0:0000}{1:00}{2:00}_{3:00}{4:00}{5:00}", n.Year, n.Month, n.Day, n.Hour, n.Minute, n.Second);

            return tmp + ".wav";
        }
        #endregion
    }
}
