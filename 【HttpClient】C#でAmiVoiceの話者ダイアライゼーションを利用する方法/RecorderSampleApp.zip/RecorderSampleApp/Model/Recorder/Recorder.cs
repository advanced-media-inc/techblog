﻿using NAudio.CoreAudioApi;
using NAudio.Wave;
using NAudio.Wave.SampleProviders;
using System;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;

namespace RecorderSampleApp
{

    class Recorder
    {
        private WaveInEvent _waveIn = new();
        private WaveFileWriter _waveFileWriter;

        public bool IsRecording
        {
            get;
            private set;
        }

        public bool Setup(string waveFileName)
        {
            try
            {
                _waveIn = new();
                _waveIn.DeviceNumber = 0;          
                _waveIn.WaveFormat = new WaveFormat(sampleRate: 16000, channels: 1); // Only monoral type

                _waveFileWriter = new WaveFileWriter(waveFileName, _waveIn.WaveFormat);

                _waveIn.DataAvailable += WaveIn_DataAvailable;
                _waveIn.RecordingStopped += WaveIn_RecordingStopped;
            }
            catch (Exception e)
            {
                Debug.WriteLine("ERROR: " + e);
            }

            if (_waveIn == null && _waveFileWriter == null) { return false; }

            return true;
        }

        public void Start()
        {
            if (_waveIn == null) { return; }
            IsRecording = true;
            _waveIn.StartRecording();
        }

        public void Stop()
        {
            if (_waveIn == null) { return; }
            IsRecording = false;
            _waveIn.StopRecording();
        }

        private void WaveIn_DataAvailable(object sender, WaveInEventArgs e)
        {
            if (_waveFileWriter == null) { return; }
            _waveFileWriter.Write(e.Buffer, 0, e.BytesRecorded);
            _waveFileWriter.Flush();
        }

        private void WaveIn_RecordingStopped(object sender, StoppedEventArgs e)
        {
            Debug.WriteLine("WaveIn_RecordingStopped");
            IsRecording = false;
            //
            _waveFileWriter.Flush();
            _waveFileWriter.Close();
            //
            _waveFileWriter.Dispose();
            _waveIn.Dispose();
            _waveIn = null;
        }
    }
}