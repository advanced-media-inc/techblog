﻿namespace RecorderSampleApp
{
    internal class ByteArraycontent
    {
        private byte[] vs;

        public ByteArraycontent(byte[] vs)
        {
            this.vs = vs;
        }
    }
}