本サンプルはフリーソフトです。自由にご使用ください。なお、著作権は作者である
株式会社アドバンスト・メディアが保有しています。

このサンプルを使用したことによって生じたすべての障害・損害・不具合等に関しては、
株式会社アドバンスト・メディアでは、一切の責任を負いません。
各自の責任においてご使用ください。
------------------------------------------------
本ソフトウェアは、以下の環境で動作を確認しています。

■OS...Windows10 Pro（バージョン: 20H2（64 ビット））
■Webブラウザ...Google Chrome（バージョン: 91.0.4472.124（Official Build）（64 ビット））
■ソフトウェア
・OBS Studio本体（ver.25.0.8）
　https://obsproject.com/ja/download
・OBS-websocketプラグイン（ver.4.8）
　https://github.com/Palakis/obs-websocket/releases
------------------------------------------------
＜素材など＞

・OBSアイコン画像は「OBS Project」からお借りしています。
　https://obsproject.com/
・マイクアイコン画像は「illust AC」からお借りしています。
　https://www.ac-illust.com/
------------------------------------------------
＜使用ライブラリのライセンス等＞
本ソフトウェアの開発にあたって、以下のライブラリを利用させていただきました。 心より感謝申し上げます。

■obs-websocket-js（MIT License）
　Copyright (c) 2016 Brendan Hagan
　https://github.com/obs-websocket-community-projects/obs-websocket-js/blob/master/LICENSE.md
　　なお、obs-websocket-jsは、CDN「jsDelivr」から利用しています。
　　https://www.jsdelivr.com/
　　
　obs-websocket-jsは以下のライブラリを使用しています。
　合わせて感謝申し上げます。
　■debug（MIT License）
　　Copyright (c) 2014-2017 TJ Holowaychuk <tj@vision-media.ca>
　　https://github.com/visionmedia/debug/blob/master/LICENSE

　■isomorphic-ws（MIT License）
　　Copyright (c) 2018 Zejin Zhuang <heineiuo@gmail.com>
　　https://github.com/heineiuo/isomorphic-ws/blob/HEAD/LICENSE

　■sha.js（MIT License）
　　Copyright (c) 2013-2018 sha.js contributors
　　https://github.com/crypto-browserify/sha.js/blob/HEAD/LICENSE

　■ws（MIT License）
　　Copyright (c) 2011 Einar Otto Stangvik <einaros@gmail.com>
　　https://github.com/websockets/ws/blob/HEAD/LICENSE
--------------------------------------------------
＜謝辞＞
このソフトウェアが使用した流用可能な公開ソースコード「obs-websocket-js」の作者であるBrendan Hagan氏、
obs-websocket-jsを利用可能なCDNで提供しているjsDelivr様、
obs-websocket-jsが使用した流用可能な公開ソースコード作者のTJ Holowaychuk氏、
obs-websocket-jsが使用した流用可能な公開ソースコード作者のZejin Zhuang氏、
obs-websocket-jsが使用した流用可能な公開ソースコード作者のsha.js contributors様、
obs-websocket-jsが使用した流用可能な公開ソースコード作者のEinar Otto Stangvik氏、
このソフトウェアが使用したOBS Studioのアイコンの作者のOBS Project様、
このソフトウェアが使用したマイクのアイコン画像の作者のillust AC様、
このソフトウェアを使用する上で必須となるwebライブ配信システム「OBS Studio」作者のOBS Project様
このソフトウェアを使用する上で必須となるOBS Studioの拡張プラグイン「OBS WebSocket」作者のOBS Project様、
このソフトウェアを用いた動画投稿やライブ配信を公開された方々、
そして、このソフトウェアをお使い頂いた全ての方々。

以上の方々に心より感謝申し上げます。